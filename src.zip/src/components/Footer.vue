<template>
    <v-footer class="pa-3">
        <v-spacer></v-spacer>
        <div>&copy; {{ new Date().getFullYear() }}</div>
    </v-footer>
</template>

<script>
export default{
    name:  'Footer'
    }
</script>

<style lang="scss" scoped>
</style>
