<template>
  <v-toolbar>
    <v-toolbar-side-icon></v-toolbar-side-icon>
    <img src="./pic/Image2.gif" width="180" height="70">
    <v-spacer></v-spacer>
    <span><a style="font-weight:bold">PSEUDO</a></span>
    <v-btn color="white" fab></v-btn>
  </v-toolbar>
</template>